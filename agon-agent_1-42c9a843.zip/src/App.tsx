import { AnimatePresence, motion } from 'framer-motion'
import {
  CalendarDays,
  ChevronRight,
  Clock3,
  Flame,
  Instagram,
  MapPin,
  Martini,
  MessageCircle,
  Mic,
  Phone,
  Star,
  Trophy,
  Users,
} from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'

type Category =
  | 'Shawarma'
  | 'Combos de Shawarma'
  | 'Hamburguesas'
  | 'Combo de Hamburguesas'
  | 'Alitas'
  | 'Combo de Alitas'
  | 'Parrilladas'
  | 'Papas'
  | 'Picadas'
  | 'Bebidas'
  | 'Cocteles'
  | 'Micheladas'
  | 'Milkshakes'
  | 'Artesanales'
  | 'Pipas'
  | 'Extras'

type MenuItem = {
  id: string
  category: Category
  name: string
  price: number
  description: string
  tags?: string[]
}

type CartItem = MenuItem & { quantity: number }

const WHATSAPP_NUMBER = '593983553243'
const PHONE_DISPLAY = '0983553243'
const MENU_LINK =
  'https://www.canva.com/design/DAF2VmFmlPQ/dTbxaFP2NCH7svOMk0jY8A/view?utm_content=DAF2VmFmlPQ&utm_campaign=designshare&utm_medium=link&utm_source=viewer'
const MAP_LINK =
  'https://www.google.com/maps/search/?api=1&query=PERSEPOLIS+RESTOBAR+REAL+AUDIENCIA'
const FACEBOOK_LINK =
  'https://www.facebook.com/Persepolis.ec?mibextid=wwXIfr&rdid=lkg2oPlvtX3yN6iY&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1Gvn1bx39w%2F%3Fmibextid%3DwwXIfr'
const INSTAGRAM_LINK =
  'https://www.instagram.com/persepolis.uio?igsh=MXF1MjZoeWtzODZ3OA=='
const RAPPI_LINK =
  'https://www.rappi.com.ec/quito/restaurantes/delivery/7726-persepolis-bar-y-restaurant'
const PEDIDOS_YA_LINK =
  'https://www.pedidosya.com.ec/restaurantes/quito/persepolis-resto-bar-1319d604-b49e-47bc-9455-abf6b50991dc-menu'
const UBER_EATS_LINK =
  'https://www.ubereats.com/ec/store/bar-restaurant-persepolis/9V79AdIPRt-ZS3a3pZ1rhA'
const LOGO_PATH = '/uploads/upload_1.jpeg'
const HERO_BACKGROUND = 'https://cdn.phototourl.com/free/2026-04-08-2c29a64a-a158-4251-8b62-e2dc7a533ab4.jpg'
const BUSINESS_HOURS = [
  'Lunes: 3pm – 11pm',
  'Martes: 3pm – 11pm',
  'Miércoles: 3pm – 11pm',
  'Jueves: 3pm – 1am',
  'Viernes: 3pm – 2am',
  'Sábado: 3pm – 2am',
  'Domingo: 12pm – 9:30pm',
]
const ORDER_WHATSAPP_MESSAGE = encodeURIComponent(
  'Hola, Quiero hacer un pedido por favor.',
)
const WHATSAPP_GREETING = encodeURIComponent(
  'Hola, quiero más información sobre Persepolis Restobar.',
)
const promotions = [
  {
    title: 'Lunes',
    offer: 'Segunda hamburguesa a mitad de precio',
    icon: Flame,
  },
  {
    title: 'Martes',
    offer: '2 x 1 alitas',
    icon: Flame,
  },
  {
    title: 'Miércoles',
    offer: '3 shawarmas de pollo por $8.50',
    icon: Flame,
  },
  {
    title: 'Jueves',
    offer: '2 micheladas por $7',
    icon: Martini,
  },
  {
    title: 'Todos los días',
    offer: '3 cocteles por $16',
    icon: Martini,
  },
  {
    title: 'Todos los días',
    offer: '3 coronas por $12',
    icon: Flame,
  },
  {
    title: 'Todos los días',
    offer: '3 cervezas artesanales $12.50',
    icon: Flame,
  },
  {
    title: 'Todos los días',
    offer: '2 peceras por $26.50',
    icon: Flame,
  },
]
const GALLERY_IMAGES = [
  'https://cdn.phototourl.com/free/2026-04-08-33430e49-44ef-45ea-879b-4d14583b131b.jpg',
  'https://cdn.phototourl.com/free/2026-04-08-9d21b2a5-37b1-40e9-ad11-2095a4279ee8.jpg',
  'https://cdn.phototourl.com/free/2026-04-08-512cd8d6-9631-41cb-88a0-de1bcca14129.jpg',
  'https://cdn.phototourl.com/free/2026-04-08-e8d99d19-19ca-49e1-8bc3-ae0745cee2dc.jpg',
]
const reviews = [
  {
    name: 'Micaela Robalino Carrera',
    meta: '5 reseñas · 8 fotos',
    time: 'Hace 3 meses',
    price: '$5–10',
    text: 'Me sentí muy decepcionada con mi experiencia en este restaurante. Aunque la decoración es bonita y el ambiente es agradable, en general deja mucho que desear.',
  },
  {
    name: 'Xavier Freire O. (xavfo)',
    meta: 'Guía local · 203 reseñas · 310 fotos',
    time: 'Hace 3 meses',
    price: '$10–15',
    text: 'En un fin de semana concurrido, la comida puede tardar hasta 40 minutos en llegar. El sistema de pedidos no está bien organizado. No me gusta el área de fumadores dentro del lugar; o te acaloras o terminas entre humo. No es un sitio para conversar.',
  },
  {
    name: 'Alex Ortega',
    meta: '1 reseña',
    time: 'Hace 4 semanas',
    price: '',
    text: 'La atención no es tan buena; no siempre traen lo que uno pide y a veces llega algo distinto. La comida sí es rica y el ambiente es agradable.',
  },
]

const currency = (value: number) => `ECS ${value.toFixed(2)}`

function App() {
  const [cart] = useState<Record<string, CartItem>>({})
  const [loading, setLoading] = useState(true)
  const [reservationSent, setReservationSent] = useState(false)
  const [cursor, setCursor] = useState({ x: 0, y: 0 })
  const [reservation, setReservation] = useState({
    name: '',
    people: '2',
    date: '',
    time: '',
    notes: '',
    decoration: false,
  })
  const [reservationErrors, setReservationErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    const timer = window.setTimeout(() => setLoading(false), 1200)
    return () => window.clearTimeout(timer)
  }, [])

  useEffect(() => {
    const move = (event: MouseEvent) => setCursor({ x: event.clientX, y: event.clientY })
    window.addEventListener('mousemove', move)
    return () => window.removeEventListener('mousemove', move)
  }, [])

  const cartItems = useMemo(() => Object.values(cart), [cart])
  const cartTotal = useMemo(
    () => cartItems.reduce((total, item) => total + item.price * item.quantity, 0),
    [cartItems],
  )

  const orderMessage = useMemo(() => {
    const lines = cartItems.map((item) => `- ${item.quantity}x ${item.name}`)
    return `Hola, quiero hacer un pedido:%0A${lines.join('%0A')}%0ATotal: ${currency(cartTotal)}%0ANombre:%0ADirección:%0AMétodo de pago:`
  }, [cartItems, cartTotal])

  const reservationMessage = useMemo(() => {
    const decorationLine = reservation.decoration ? '%0AExtra: Decoración para cumpleaños (+$5)' : ''
    return `Hola, quiero reservar una mesa:%0ANombre: ${reservation.name}%0APersonas: ${reservation.people}%0AFecha: ${reservation.date}%0AHora: ${reservation.time}%0AComentarios: ${reservation.notes || 'Ninguno'}${decorationLine}`
  }, [reservation])

  const validateReservation = () => {
    const errors: Record<string, string> = {}
    if (!reservation.name.trim()) errors.name = 'Ingresa tu nombre'
    if (!reservation.people.trim()) errors.people = 'Añade el número de personas'
    if (!reservation.date.trim()) errors.date = 'Selecciona la cita'
    if (!reservation.time.trim()) errors.time = 'Selecciona el tiempo'
    setReservationErrors(errors)
    return Object.keys(errors).length === 0
  }

  const sendReservation = () => {
    if (!validateReservation()) return
    setReservationSent(true)
    window.setTimeout(() => setReservationSent(false), 1800)
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${reservationMessage}`, '_blank')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] text-[#f5e7b2] flex items-center justify-center overflow-hidden">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative flex flex-col items-center gap-6"
        >
          <div className="absolute h-40 w-40 rounded-full bg-[#c7a44d]/20 blur-3xl" />
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 3, ease: 'linear' }}
            className="h-20 w-20 rounded-full border border-[#c7a44d]/40 border-t-[#f5e7b2]"
          />
          <div className="text-center">
            <p className="text-xs uppercase tracking-[0.5em] text-[#c7a44d]">Persepolis Restobar</p>
            <h1 className="mt-3 text-3xl font-semibold tracking-[0.2em]">Real Audiencia</h1>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="relative bg-[#050505] text-white selection:bg-[#c7a44d] selection:text-black">
      <div className="pointer-events-none fixed inset-0 z-0 bg-[url('/uploads/upload_1.jpeg')] bg-cover bg-center bg-fixed opacity-[0.18]" />
      <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(180deg,rgba(5,5,5,0.9),rgba(5,5,5,0.78),rgba(5,5,5,0.94))]" />
      <div
        className="pointer-events-none fixed inset-0 z-10 hidden md:block"
        style={{
          background: `radial-gradient(320px at ${cursor.x}px ${cursor.y}px, rgba(199,164,77,0.14), transparent 60%)`,
        }}
      />

      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#050505]/80 backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-2xl border border-[#c7a44d]/30 bg-black/30 shadow-[0_0_30px_rgba(199,164,77,0.15)]">
              <img src={LOGO_PATH} alt="Persepolis Restobar logo" className="h-full w-full object-cover" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-[0.6em] text-[#c7a44d]">Quito · Siempre abierto al buen ambiente</p>
              <h1 className="text-lg font-semibold tracking-[0.28em] md:text-xl">PERSEPOLIS RESTOBAR</h1>
            </div>
          </div>
        </nav>
      </header>

      <main className="relative z-20 scroll-smooth">
        <section id="inicio" className="relative flex min-h-screen overflow-hidden border-b border-white/10">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url('${HERO_BACKGROUND}')` }}
          />
          <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(5,5,5,0.72),rgba(5,5,5,0.56),rgba(5,5,5,0.84))]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(199,164,77,0.12),transparent_55%)]" />
          <div className="mx-auto flex min-h-screen w-full max-w-7xl items-center justify-center px-4 py-24 md:px-8 md:py-28">
            <motion.div
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
              className="relative z-10 -translate-y-8 md:-translate-y-12 flex max-w-4xl flex-col items-center justify-center space-y-8 text-center"
            >
              <div className="relative">
                <div className="absolute inset-0 rounded-full bg-[#c7a44d]/20 blur-3xl" />
                <div className="relative h-32 w-32 overflow-hidden rounded-full border border-[#c7a44d]/40 bg-black/30 shadow-[0_0_50px_rgba(199,164,77,0.22)] md:h-40 md:w-40">
                  <img src={LOGO_PATH} alt="Persepolis Restobar logo" className="h-full w-full object-cover" />
                </div>
              </div>
              <div className="flex flex-col items-center justify-center space-y-5 text-center">
                <p className="text-sm uppercase tracking-[0.55em] text-[#c7a44d]">Real Audiencia y Sabanilla</p>
                <h2 className="max-w-4xl text-5xl font-semibold leading-none tracking-[0.08em] text-white md:text-7xl">
                  PERSEPOLIS
                </h2>
                <p className="mx-auto max-w-2xl text-center text-lg leading-8 text-white/70">
                  Sabores intensos, ambiente exclusivo y una experiencia pensada para disfrutar, compartir y volver por más.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="border-b border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <div className="mb-10 text-center">
              <div>
                <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Menú completo</p>
                <h3 className="mt-3 text-3xl font-semibold tracking-[0.08em]">Accede al menú oficial</h3>
                <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-white/60">
                  Consulta todas las categorías, promociones y precios completos en el menú oficial de Persepolis.
                </p>
              </div>
            </div>
            <motion.a
              id="menu-completo"
              href={MENU_LINK}
              target="_blank"
              rel="noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              className="mx-auto flex max-w-3xl items-center justify-center rounded-[2rem] border border-[#c7a44d]/35 bg-[linear-gradient(180deg,rgba(199,164,77,0.18),rgba(255,255,255,0.04))] px-8 py-8 text-center text-2xl font-semibold uppercase tracking-[0.28em] text-[#f5e7b2] shadow-[0_0_60px_rgba(199,164,77,0.16)] transition hover:scale-[1.01] hover:border-[#c7a44d]/60 hover:shadow-[0_0_75px_rgba(199,164,77,0.28)] md:text-4xl"
            >
              VER MENU COMPLETO
            </motion.a>
          </div>
        </section>

        <section id="reseñas" className="border-b border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <div className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Reseñas</p>
                <h3 className="mt-3 text-3xl font-semibold tracking-[0.08em]">Lo que dicen los clientes</h3>
                <p className="mt-4 max-w-2xl text-sm leading-7 text-white/60">
                  Opiniones recientes para dar contexto real sobre servicio, ambiente y experiencia general.
                </p>
              </div>
              <div className="rounded-full border border-[#c7a44d]/30 bg-[#c7a44d]/10 px-4 py-2 text-xs uppercase tracking-[0.35em] text-[#f5e7b2]">
                4.4★ Calificación en Google
              </div>
            </div>

            <div className="grid gap-5 lg:grid-cols-3">
              {reviews.map((review, index) => (
                <motion.div
                  key={review.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ delay: index * 0.08 }}
                  className="rounded-[1.75rem] border border-white/10 bg-white/[0.03] p-6"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h4 className="text-lg font-semibold text-white">{review.name}</h4>
                      <p className="mt-1 text-sm text-white/45">{review.meta}</p>
                    </div>
                    <div className="flex items-center gap-1 text-[#f5e7b2]">
                      {Array.from({ length: 4 }).map((_, starIndex) => (
                        <Star key={starIndex} size={14} fill="currentColor" />
                      ))}
                    </div>
                  </div>
                  <div className="mt-5 flex items-center gap-3 text-xs uppercase tracking-[0.25em] text-white/45">
                    <span>{review.time}</span>
                    {review.price && <span>{review.price}</span>}
                  </div>
                  <p className="mt-5 text-sm leading-7 text-white/70">{review.text}</p>
                  <p className="mt-4 text-xs text-white/40">Translated by Google·See original (Spanish)</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="galería" className="border-b border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <div className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Galería</p>
                <h3 className="mt-3 text-3xl font-semibold tracking-[0.08em]">Ambiente de Persepolis</h3>
                <p className="mt-4 max-w-2xl text-sm leading-7 text-white/60">
                  Una selección visual para mostrar la energía del espacio, la presentación de los platos y la vibra nocturna de Persepolis.
                </p>
              </div>
              <div className="rounded-full border border-[#c7a44d]/30 bg-[#c7a44d]/10 px-4 py-2 text-xs uppercase tracking-[0.35em] text-[#f5e7b2]">
                Sextupción visual
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {GALLERY_IMAGES.map((image, index) => (
                <motion.div
                  key={`${image}-${index}`}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ delay: index * 0.06 }}
                  className="group relative overflow-hidden rounded-[1.75rem] border border-white/10 bg-black/20"
                >
                  <div
                    className="h-72 w-full bg-cover bg-center transition duration-500 group-hover:scale-105"
                    style={{ backgroundImage: `url('${image}')` }}
                  />
                  <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent,rgba(5,5,5,0.72))]" />
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <p className="text-xs uppercase tracking-[0.35em] text-[#f5e7b2]">Persepolis</p>
                    <p className="mt-2 text-sm text-white/70">Experiencia visual del restobar</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="promociones" className="border-b border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <div className="mb-10 text-center">
              <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">PROMOCIONES</p>
              <h3 className="mt-3 text-3xl font-semibold tracking-[0.08em]">Ofertas para cada día y cada noche</h3>
            </div>
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
              {promotions.map(({ title, offer, icon: Icon }) => (
                <motion.div
                  key={`${title}-${offer}`}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  className="rounded-[1.75rem] border border-white/10 bg-[linear-gradient(180deg,rgba(199,164,77,0.08),rgba(255,255,255,0.03))] p-6"
                >
                  <div className="inline-flex rounded-2xl bg-[#c7a44d]/10 p-3 text-[#f5e7b2]">
                    <Icon size={20} />
                  </div>
                  <p className="mt-4 text-xs uppercase tracking-[0.35em] text-[#c7a44d]">{title}</p>
                  <h4 className="mt-3 text-xl font-semibold text-white">{offer}</h4>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              className="mx-auto mt-8 max-w-2xl rounded-[1.9rem] border border-[#c7a44d]/35 bg-[linear-gradient(180deg,rgba(199,164,77,0.16),rgba(255,255,255,0.03))] p-7 text-center shadow-[0_0_60px_rgba(199,164,77,0.14)]"
            >
              <div className="mx-auto inline-flex rounded-2xl bg-[#c7a44d]/10 p-3 text-[#f5e7b2]">
                <Martini size={22} />
              </div>
              <p className="mt-4 text-xs uppercase tracking-[0.35em] text-[#c7a44d]">Promoción de Micheladas</p>
              <h4 className="mt-3 text-3xl font-semibold text-white">3 micheladas por $12</h4>
              <p className="mt-3 text-sm leading-7 text-white/65">Perfectas para compartir, brindar y mantener la noche encendida.</p>
            </motion.div>
          </div>
        </section>

        <section className="border-b border-white/10 py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <div className="grid gap-5 md:grid-cols-3">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                className="rounded-[1.75rem] border border-white/10 bg-[linear-gradient(180deg,rgba(199,164,77,0.08),rgba(255,255,255,0.03))] p-6"
              >
                <div className="inline-flex rounded-2xl bg-[#c7a44d]/10 p-3 text-[#f5e7b2]">
                  <Mic size={20} />
                </div>
                <p className="mt-4 text-xs uppercase tracking-[0.35em] text-[#c7a44d]">Karaoke</p>
                <h4 className="mt-3 text-2xl font-semibold text-white">🎤 Sube el volumen de tu noche</h4>
                <p className="mt-3 max-w-xl text-sm leading-7 text-white/65">
                  El espacio ideal para cantar, soltar la voz y convertir cualquier salida en una noche inolvidable.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: 0.04 }}
                className="rounded-[1.75rem] border border-[#c7a44d]/25 bg-[linear-gradient(180deg,rgba(199,164,77,0.12),rgba(255,255,255,0.03))] p-6 text-center shadow-[0_0_45px_rgba(199,164,77,0.12)]"
              >
                <div className="mx-auto inline-flex rounded-2xl bg-[#c7a44d]/10 p-3 text-[#f5e7b2]">
                  <Flame size={20} />
                </div>
                <p className="mt-4 text-xs uppercase tracking-[0.35em] text-[#c7a44d]">Pipas</p>
                <h4 className="mt-3 text-2xl font-semibold text-white">Humo, lounge y actitud</h4>
                <p className="mt-3 text-sm leading-7 text-white/65">
                  Un mood relajado y cool para acompañar tragos, música y buena conversación.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: 0.08 }}
                className="rounded-[1.75rem] border border-white/10 bg-[linear-gradient(180deg,rgba(199,164,77,0.08),rgba(255,255,255,0.03))] p-6"
              >
                <div className="inline-flex rounded-2xl bg-[#c7a44d]/10 p-3 text-[#f5e7b2]">
                  <Trophy size={20} />
                </div>
                <p className="mt-4 text-xs uppercase tracking-[0.35em] text-[#c7a44d]">Juegos de mesa</p>
                <h4 className="mt-3 text-2xl font-semibold text-white">Diversión para compartir</h4>
                <p className="mt-3 max-w-xl text-sm leading-7 text-white/65">
                  Risas, retos y buenas conversaciones en una mesa pensada para disfrutar sin prisa.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        <section id="pedir-ahora" className="border-b border-white/10 py-20 md:min-h-screen md:flex md:items-center">
          <div className="mx-auto w-full max-w-7xl px-4 md:px-8">
            <motion.div
              initial={{ opacity: 0, x: -24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 md:p-8"
            >
              <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Sistema inteligente de pedidos</p>
              <h3 className="mt-3 text-3xl font-semibold tracking-[0.08em]">Pedir ahora</h3>

              <div className="mt-8 space-y-4">
                {cartItems.length === 0 ? null : (
                  cartItems.map((item) => (
                    <div key={item.id} className="flex items-center justify-between gap-4 rounded-3xl border border-white/10 bg-black/20 p-4">
                      <div>
                        <h4 className="font-medium text-white">{item.name}</h4>
                        <p className="mt-1 text-sm text-white/55">{currency(item.price)} c/u</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="rounded-full border border-white/10 px-4 py-2 text-sm text-white/70">{item.quantity}x</span>
                        <p className="w-24 text-right font-medium text-[#f5e7b2]">{currency(item.quantity * item.price)}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="mt-8 rounded-[1.75rem] border border-[#c7a44d]/20 bg-[linear-gradient(180deg,rgba(199,164,77,0.08),rgba(255,255,255,0.02))] p-6">
                {cartItems.length > 0 ? (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-sm uppercase tracking-[0.35em] text-white/55">Resumen del pedido</span>
                      <span className="text-3xl font-semibold text-[#f5e7b2]">{currency(cartTotal)}</span>
                    </div>
                    <div className="mt-6 rounded-3xl border border-white/10 bg-black/30 p-4 text-sm leading-7 text-white/70">
                      {decodeURIComponent(orderMessage)}
                    </div>
                  </>
                ) : (
                  <div className="mt-6 rounded-3xl border border-white/10 bg-black/30 p-4 text-sm leading-7 text-white/70">
                    Agrega productos del menú para generar tu pedido por WhatsApp.
                  </div>
                )}
                <div className="mt-6 grid gap-3 sm:grid-cols-1 md:max-w-sm">
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${ORDER_WHATSAPP_MESSAGE}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-[#c7a44d] px-4 py-3 font-medium text-black transition hover:shadow-[0_0_40px_rgba(199,164,77,0.35)]"
                  >
                    <MessageCircle size={16} /> WhatsApp
                  </a>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <a href={RAPPI_LINK} target="_blank" rel="noreferrer" className="rounded-full border border-white/10 px-4 py-3 text-center text-sm text-white/75 transition hover:border-[#c7a44d]/40 hover:text-[#f5e7b2]">Rappi</a>
                  <a href={PEDIDOS_YA_LINK} target="_blank" rel="noreferrer" className="rounded-full border border-white/10 px-4 py-3 text-center text-sm text-white/75 transition hover:border-[#c7a44d]/40 hover:text-[#f5e7b2]">PedidosYa</a>
                  <a href={UBER_EATS_LINK} target="_blank" rel="noreferrer" className="rounded-full border border-white/10 px-4 py-3 text-center text-sm text-white/75 transition hover:border-[#c7a44d]/40 hover:text-[#f5e7b2]">UberEats</a>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section id="reservar" className="border-b border-white/10 py-20">
          <div className="mx-auto grid max-w-7xl gap-8 px-4 md:grid-cols-[0.95fr_1.05fr] md:px-8">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 md:p-8"
            >
              <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Sistema inteligente de reservas</p>
              <h3 className="mt-3 text-3xl font-semibold tracking-[0.08em]">Reservar mesa</h3>
              <p className="mt-4 text-sm leading-7 text-white/65">
                Completa tus datos, añade comentarios opcionales y envía una solicitud automatizada por WhatsApp. Incluye <span className="text-[#f5e7b2]">+5$ decoración para cumpleaños</span>.
              </p>

              <div className="mt-8 grid gap-4">
                <label className="space-y-2">
                  <span className="text-sm text-white/70">Nombre</span>
                  <input
                    value={reservation.name}
                    onChange={(event) => setReservation((prev) => ({ ...prev, name: event.target.value }))}
                    className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 outline-none transition focus:border-[#c7a44d]/50"
                    placeholder="Tu nombre"
                  />
                  {reservationErrors.name && <span className="text-xs text-red-300">{reservationErrors.name}</span>}
                </label>

                <label className="space-y-2">
                  <span className="text-sm text-white/70">Número de personas</span>
                  <input
                    value={reservation.people}
                    onChange={(event) => setReservation((prev) => ({ ...prev, people: event.target.value }))}
                    className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 outline-none transition focus:border-[#c7a44d]/50"
                    placeholder="2"
                    type="number"
                    min="1"
                  />
                  {reservationErrors.people && <span className="text-xs text-red-300">{reservationErrors.people}</span>}
                </label>

                <div className="mx-auto grid max-w-[18rem] grid-cols-2 gap-8 md:max-w-[22rem] md:gap-10">
                  <label className="space-y-2">
                    <span className="text-sm text-white/70">cita</span>
                    <input
                      value={reservation.date}
                      onChange={(event) => setReservation((prev) => ({ ...prev, date: event.target.value }))}
                      className="w-full rounded-2xl border border-white/10 bg-black/20 px-2.5 py-2 text-xs outline-none transition focus:border-[#c7a44d]/50 md:px-3 md:py-2.5 md:text-sm"
                      type="date"
                    />
                    {reservationErrors.date && <span className="text-xs text-red-300">{reservationErrors.date}</span>}
                  </label>
                  <label className="space-y-2">
                    <span className="text-sm text-white/70">tiempo</span>
                    <input
                      value={reservation.time}
                      onChange={(event) => setReservation((prev) => ({ ...prev, time: event.target.value }))}
                      className="w-full rounded-2xl border border-white/10 bg-black/20 px-2.5 py-2 text-xs outline-none transition focus:border-[#c7a44d]/50 md:px-3 md:py-2.5 md:text-sm"
                      type="time"
                    />
                    {reservationErrors.time && <span className="text-xs text-red-300">{reservationErrors.time}</span>}
                  </label>
                </div>

                <label className="space-y-2">
                  <span className="text-sm text-white/70">Descripción (opcional)</span>
                  <textarea
                    value={reservation.notes}
                    onChange={(event) => setReservation((prev) => ({ ...prev, notes: event.target.value }))}
                    className="min-h-28 w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 outline-none transition focus:border-[#c7a44d]/50"
                    placeholder="Celebración, zona preferida, detalles adicionales..."
                  />
                </label>

                <button
                  type="button"
                  onClick={() => setReservation((prev) => ({ ...prev, decoration: !prev.decoration }))}
                  className={`flex items-center justify-between rounded-2xl border px-4 py-3 text-left transition ${reservation.decoration ? 'border-[#c7a44d]/50 bg-[#c7a44d]/10' : 'border-white/10 bg-black/20'}`}
                >
                  <span>
                    <span className="block text-sm font-medium text-white">Decoración para cumpleaños</span>
                    <span className="mt-1 block text-xs text-white/55">+5$ decoración para cumpleaños</span>
                  </span>
                  <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-[#f5e7b2]">{reservation.decoration ? 'Añadido' : 'Agregar'}</span>
                </button>

                <button
                  type="button"
                  onClick={sendReservation}
                  className="inline-flex items-center justify-center gap-3 rounded-full bg-[#c7a44d] px-6 py-4 font-medium text-black transition hover:shadow-[0_0_45px_rgba(199,164,77,0.38)]"
                >
                  <MessageCircle size={18} /> WhatsApp
                </button>

                <AnimatePresence>
                  {reservationSent && (
                    <motion.div
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      className="rounded-2xl border border-emerald-400/20 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200"
                    >
                      Reserva validada. Abriendo WhatsApp con tu mensaje automático.
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              className="space-y-6"
            >
              <div className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 md:p-8">
                <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Mensaje automático</p>
                <div className="mt-5 rounded-3xl border border-white/10 bg-black/25 p-5 text-sm leading-7 text-white/70">
                  {decodeURIComponent(reservationMessage)}
                </div>
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                {[
                  { icon: Users, title: 'Mesas para grupos', text: 'Configura personas y requerimientos con precisión.' },
                  { icon: Clock3, title: 'Tiempo optimizado', text: 'La cita y el tiempo se envían listos al canal de atención.' },
                  { icon: Star, title: 'Experiencia premium', text: 'Validación, confirmación visual y flujo sin fricción.' },
                  { icon: CalendarDays, title: 'Eventos especiales', text: 'Incluye decoración para cumpleaños con un toque extra.' },
                ].map(({ icon: Icon, title, text }) => (
                  <div key={title} className="rounded-[1.75rem] border border-white/10 bg-black/20 p-5">
                    <div className="inline-flex rounded-2xl bg-[#c7a44d]/10 p-3 text-[#f5e7b2]">
                      <Icon size={18} />
                    </div>
                    <h4 className="mt-4 text-lg font-medium text-white">{title}</h4>
                    <p className="mt-2 text-sm leading-7 text-white/60">{text}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        <section id="contacto" className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 md:p-8">
                <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Contacto & negocio</p>
                <h3 className="mt-3 text-3xl font-semibold tracking-[0.08em]">Siempre listos para atender</h3>
                <div className="mt-8 grid gap-4 sm:grid-cols-2">
                  {[
                    { icon: MapPin, label: 'Dirección', value: 'Real Audiencia, y y Sabanilla, 170501 Quito' },
                    { icon: Phone, label: 'Teléfono', value: PHONE_DISPLAY },
                    { icon: Clock3, label: 'Horario', value: BUSINESS_HOURS.join(' • ') },
                    { icon: Star, label: 'Calificación en Google', value: '4.4★' },
                  ].map(({ icon: Icon, label, value }) => (
                    <div key={label} className="rounded-[1.5rem] border border-white/10 bg-black/20 p-5">
                      <div className="inline-flex rounded-2xl bg-[#c7a44d]/10 p-3 text-[#f5e7b2]">
                        <Icon size={18} />
                      </div>
                      <p className="mt-4 text-sm uppercase tracking-[0.28em] text-white/45">{label}</p>
                      <p className="mt-2 text-lg text-white">{value}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                  <a href={MAP_LINK} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#c7a44d] px-5 py-3 font-medium text-black transition hover:shadow-[0_0_40px_rgba(199,164,77,0.35)]">Llegar ahora</a>
                  <a href={`tel:${PHONE_DISPLAY.replace(/\s+/g, '')}`} className="inline-flex items-center justify-center gap-2 rounded-full border border-white/15 bg-white/[0.03] px-5 py-3 font-medium text-white transition hover:border-[#c7a44d]/40 hover:text-[#f5e7b2]">Llamar ahora</a>
                </div>
              </div>

              <div className="rounded-[2rem] border border-[#c7a44d]/20 bg-[linear-gradient(180deg,rgba(199,164,77,0.08),rgba(255,255,255,0.02))] p-6 md:p-8">
                <p className="text-xs uppercase tracking-[0.45em] text-[#c7a44d]">Social & traffic</p>
                <h3 className="mt-3 text-2xl font-semibold">Canales externos conectados</h3>
                <div className="mt-6 grid gap-3">
                  <a href={FACEBOOK_LINK} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/20 px-4 py-4 text-white/75 transition hover:border-[#c7a44d]/40 hover:text-[#f5e7b2]">
                    Facebook <ChevronRight size={16} />
                  </a>
                  <a href={INSTAGRAM_LINK} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/20 px-4 py-4 text-white/75 transition hover:border-[#c7a44d]/40 hover:text-[#f5e7b2]">
                    <span className="inline-flex items-center gap-2"><Instagram size={16} /> Instagram</span> <ChevronRight size={16} />
                  </a>
                  <a href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_GREETING}`} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/20 px-4 py-4 text-white/75 transition hover:border-[#c7a44d]/40 hover:text-[#f5e7b2]">
                    WhatsApp <ChevronRight size={16} />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <a
        href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_GREETING}`}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-3 rounded-full border border-[#c7a44d]/40 bg-[#0d0d0d]/90 px-5 py-3 text-sm font-medium text-[#f5e7b2] shadow-[0_0_40px_rgba(199,164,77,0.2)] backdrop-blur-xl transition hover:scale-[1.02] hover:shadow-[0_0_55px_rgba(199,164,77,0.35)]"
      >
        <MessageCircle size={16} /> Reservas y Pedidos por WhatsApp
      </a>
    </div>
  )
}

export default App
